<?php
// Signaling API for video calls (WebRTC). Video itself goes peer-to-peer; this only passes small
// setup messages (invite / accept / offer / answer / ice / hangup) between two logged-in users.
require_once 'config.php';
header('Content-Type: application/json');

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'auth']);
    exit();
}
$me = (int)$_SESSION['user_id'];
$action = $_GET['action'] ?? '';
session_write_close();

// Own table, created automatically (same approach as config.php). Nothing existing is touched.
$conn->query("CREATE TABLE IF NOT EXISTS call_signals (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, from_id INT NOT NULL, to_id INT NOT NULL,
    type VARCHAR(20) NOT NULL, payload MEDIUMTEXT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_to (to_id, id),
    FOREIGN KEY (from_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB");

// Keep the table tiny: signals are only useful for a few seconds.
$conn->query("DELETE FROM call_signals WHERE created_at < NOW() - INTERVAL 5 MINUTE");

// Start point for a client: only look at signals created after this.
if ($action === 'init') {
    $r = $conn->query("SELECT COALESCE(MAX(id),0) AS m FROM call_signals")->fetch_assoc();
    echo json_encode(['last' => (int)$r['m']]);
    exit();
}

if ($action === 'poll') {
    $since = (int)($_GET['since'] ?? 0);
    $st = $conn->prepare("SELECT s.id, s.from_id, s.type, s.payload, u.name,
                                 TIMESTAMPDIFF(SECOND, s.created_at, NOW()) AS age
                          FROM call_signals s JOIN users u ON u.id = s.from_id
                          WHERE s.to_id = ? AND s.id > ? ORDER BY s.id ASC LIMIT 100");
    $st->bind_param("ii", $me, $since);
    $st->execute();
    $out = [];
    foreach ($st->get_result() as $r) {
        $out[] = ['id' => (int)$r['id'], 'from' => (int)$r['from_id'], 'name' => $r['name'],
                  'type' => $r['type'], 'payload' => $r['payload'], 'age' => (int)$r['age']];
    }
    echo json_encode(['signals' => $out]);
    exit();
}

if ($action === 'send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $to      = (int)($_POST['to'] ?? 0);
    $type    = $_POST['type'] ?? '';
    $payload = $_POST['payload'] ?? '';
    $allowed = ['invite', 'accept', 'decline', 'busy', 'offer', 'answer', 'ice', 'hangup'];
    if ($to === $me || !in_array($type, $allowed, true) || strlen($payload) > 60000) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid']);
        exit();
    }
    $chk = $conn->prepare("SELECT id FROM users WHERE id = ?");
    $chk->bind_param("i", $to);
    $chk->execute();
    if (!$chk->get_result()->num_rows) {
        http_response_code(404);
        echo json_encode(['error' => 'no such user']);
        exit();
    }
    $ins = $conn->prepare("INSERT INTO call_signals (from_id, to_id, type, payload) VALUES (?, ?, ?, ?)");
    $ins->bind_param("iiss", $me, $to, $type, $payload);
    $ins->execute();
    echo json_encode(['ok' => true]);
    exit();
}

http_response_code(400);
echo json_encode(['error' => 'bad action']);
