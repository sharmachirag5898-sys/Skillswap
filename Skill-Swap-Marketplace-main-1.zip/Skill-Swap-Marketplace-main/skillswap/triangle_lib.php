<?php
/**
 * 3-way skill swap matching (pure logic, no database).
 *
 * A "give" edge  X -> Y  exists when X offers at least one skill that Y wants.
 * A 3-way swap for $me is a cycle   me -> P -> Q -> me   of three different people:
 *   - I teach P something P wants,
 *   - P teaches Q something Q wants,
 *   - Q teaches me something I want.
 * (Everybody both teaches one person and learns from another.)
 *
 * $people: [ userId => ['name'=>string, 'online'=>bool, 'offer'=>[skill,...], 'want'=>[skill,...]] ]  (must include $me)
 * Returns a list of cycles, best first. Each:
 *   ['p'=>[id,name,online], 'q'=>[id,name,online], 'meToP'=>[skills], 'pToQ'=>[skills], 'qToMe'=>[skills], 'score'=>int]
 */
function triangleGive(array $from, array $to): array {
    return array_values(array_intersect($from['offer'], $to['want']));
}

function hasDirectSwap(int $me, array $people): bool {
    foreach ($people as $id => $o) {
        if ($id === $me) continue;
        if (triangleGive($people[$me], $o) && triangleGive($o, $people[$me])) return true;
    }
    return false;
}

function findTriangles(int $me, array $people, int $limit = 20): array {
    if (!isset($people[$me])) return [];
    $out = [];
    $meToP = [];                       // people I can teach something to
    foreach ($people as $id => $o) {
        if ($id === $me) continue;
        $g = triangleGive($people[$me], $o);
        if ($g) $meToP[$id] = $g;
    }
    foreach ($meToP as $pId => $g1) {
        foreach ($people as $qId => $q) {
            if ($qId === $me || $qId === $pId) continue;
            $g3 = triangleGive($q, $people[$me]);       // Q teaches me
            if (!$g3) continue;
            $g2 = triangleGive($people[$pId], $q);      // P teaches Q
            if (!$g2) continue;
            $out[] = [
                'p' => ['id' => $pId, 'name' => $people[$pId]['name'], 'online' => $people[$pId]['online']],
                'q' => ['id' => $qId, 'name' => $q['name'], 'online' => $q['online']],
                'meToP' => $g1, 'pToQ' => $g2, 'qToMe' => $g3,
                'score' => count($g1) + count($g2) + count($g3)
                           + ($people[$pId]['online'] ? 1 : 0) + ($q['online'] ? 1 : 0),
            ];
        }
    }
    usort($out, fn($a, $b) => $b['score'] <=> $a['score']);
    return array_slice($out, 0, $limit);
}
