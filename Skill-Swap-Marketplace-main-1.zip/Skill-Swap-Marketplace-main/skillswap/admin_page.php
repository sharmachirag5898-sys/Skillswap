<?php
require_once 'config.php';
requireLogin();
if (($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: user_page.php");
    exit();
}

$rows = $conn->query("
    SELECT u.id, u.name, u.email, u.role, u.created_at,
           GROUP_CONCAT(DISTINCT CASE WHEN us.type='offer' THEN s.name END SEPARATOR ', ') AS offers,
           GROUP_CONCAT(DISTINCT CASE WHEN us.type='want'  THEN s.name END SEPARATOR ', ') AS wants
    FROM users u
    LEFT JOIN user_skills us ON us.user_id = u.id
    LEFT JOIN skills s ON s.id = us.skill_id
    GROUP BY u.id ORDER BY u.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Skill Swap — Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="skillswap.css?v=<?= filemtime(__DIR__ . "/skillswap.css") ?>">
</head>
<body>
<nav>
  <div class="navrow">
    <a class="logo" href="user_page.php"><span class="dot">SS</span> Skill Swap</a>
    <div class="navlinks"><a href="user_page.php">Back to board</a></div>
    <div class="navauth"><a class="btn btn-ghost" href="logout.php">Log out</a></div>
  </div>
</nav>
<div class="admin">
  <h2>Admin — all members</h2>
  <table>
    <tr><th>Name</th><th>Email</th><th>Role</th><th>Teaches</th><th>Wants</th><th>Joined</th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['name']) ?></td><td><?= e($r['email']) ?></td><td><?= e($r['role']) ?></td>
      <td><?= e($r['offers']) ?></td><td><?= e($r['wants']) ?></td><td><?= e($r['created_at']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
</body>
</html>
