/* Skill Swap — scheduled calls: calendar, invitations, reminders. Self-contained; talks to api_schedule.php. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const toast = m => (typeof showToast === 'function' ? showToast(m) : alert(m));
  const MIN = 60, DAY = 86400;
  let calls = [], serverSkew = 0, viewY, viewM, selected = null, loaded = false;
  const mem = {}; // fallback when localStorage is unavailable

  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return mem[k] || null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { mem[k] = v; } }
  };
  const ME = document.body.dataset.me || '0';
  const nowSec = () => Math.floor(Date.now() / 1000) + serverSkew;

  async function api(url, data) {
    const opts = { credentials: 'same-origin' };
    if (data) { opts.method = 'POST'; opts.body = new URLSearchParams(data); }
    const r = await fetch(url, opts);
    if (r.status === 401) { location.href = 'index.php'; throw new Error('auth'); }
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'error');
    return j;
  }

  const fmtTime = ts => new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const fmtDate = ts => new Date(ts * 1000).toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
  const dayKey = d => d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate();
  const live = c => c.status === 'pending' || c.status === 'accepted';

  /* ---------- modal markup ---------- */
  const ov = document.createElement('div');
  ov.id = 'schedOverlay';
  ov.innerHTML = `
  <div class="sch-box" role="dialog" aria-label="Scheduled calls">
    <div class="sch-head"><h2>📅 Scheduled calls</h2><button type="button" class="sch-x" id="schedClose" aria-label="Close">✕</button></div>
    <div class="sch-body">
      <div class="sch-cal">
        <div class="sch-nav"><button type="button" id="calPrev" aria-label="Previous month">‹</button><strong id="calTitle"></strong><button type="button" id="calNext" aria-label="Next month">›</button><button type="button" id="calToday" class="sch-today">Today</button></div>
        <div class="sch-grid sch-dow"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div>
        <div class="sch-grid" id="calGrid"></div>
        <button type="button" class="btn btn-accent sch-new" id="schedNew">+ Schedule a call</button>
      </div>
      <div class="sch-side">
        <form id="schedForm" class="sch-form" style="display:none">
          <h3>New call</h3>
          <label>With<select id="sfWith" required></select></label>
          <label>Title <small>(optional)</small><input id="sfTitle" maxlength="120" placeholder="e.g. Guitar ↔ Excel swap"></label>
          <div class="sch-row">
            <label>Date &amp; time<input id="sfWhen" type="datetime-local" required></label>
            <label>Length<select id="sfDur"><option value="15">15 min</option><option value="30" selected>30 min</option><option value="45">45 min</option><option value="60">60 min</option><option value="90">90 min</option></select></label>
          </div>
          <div class="sch-row"><button type="submit" class="btn btn-accent">Send invite</button><button type="button" class="btn btn-ghost" id="sfCancel">Cancel</button></div>
        </form>
        <h3 id="dayTitle"></h3><div id="dayList"></div>
        <h3>Upcoming</h3><div id="upList"></div>
      </div>
    </div>
  </div>`;
  document.body.appendChild(ov);
  const banner = document.createElement('div');
  banner.id = 'schedBanners';
  document.body.appendChild(banner);

  /* ---------- calendar ---------- */
  function renderCal() {
    const first = new Date(viewY, viewM, 1);
    $('calTitle').textContent = first.toLocaleDateString([], { month: 'long', year: 'numeric' });
    const lead = (first.getDay() + 6) % 7; // Monday first
    const days = new Date(viewY, viewM + 1, 0).getDate();
    const counts = {};
    calls.filter(live).forEach(c => { const k = dayKey(new Date(c.start * 1000)); counts[k] = (counts[k] || 0) + 1; });
    const todayK = dayKey(new Date()), selK = selected ? dayKey(selected) : '';
    let h = '';
    for (let i = 0; i < lead; i++) h += '<span class="sch-cell empty"></span>';
    for (let d = 1; d <= days; d++) {
      const k = viewY + '-' + viewM + '-' + d, n = counts[k] || 0;
      h += `<button type="button" class="sch-cell${k === todayK ? ' today' : ''}${k === selK ? ' sel' : ''}" data-d="${d}">${d}${n ? `<i class="sch-dot">${n}</i>` : ''}</button>`;
    }
    $('calGrid').innerHTML = h;
    $('calGrid').querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
      selected = new Date(viewY, viewM, +b.dataset.d); renderCal(); renderLists();
    }));
  }

  function item(c) {
    const now = nowSec(), end = c.start + c.duration * MIN;
    const canJoin = c.status === 'accepted' && now >= c.start - 10 * MIN && now <= end;
    const pill = c.status === 'pending' ? (c.mine ? 'Awaiting reply' : 'Needs your reply') : c.status[0].toUpperCase() + c.status.slice(1);
    let btns = '';
    if (c.status === 'pending' && !c.mine) btns += `<button type="button" class="sch-b ok" data-act="accept" data-id="${c.id}">Accept</button><button type="button" class="sch-b" data-act="decline" data-id="${c.id}">Decline</button>`;
    if (canJoin) btns += `<button type="button" class="sch-b join" data-act="join" data-id="${c.id}">📹 Join call</button>`;
    if (live(c) && end > now && !(c.status === 'pending' && !c.mine)) btns += `<button type="button" class="sch-b" data-act="cancel" data-id="${c.id}">Cancel</button>`;
    return `<div class="sch-item st-${c.status}">
      <div class="sch-when"><b>${fmtTime(c.start)}</b><small>${fmtDate(c.start)} · ${c.duration} min</small></div>
      <div class="sch-what"><div><b>${esc(c.title || 'Skill swap call')}</b> <span class="sch-pill">${pill}</span></div>
        <div class="sch-who">${c.mine ? 'with' : 'from'} ${esc(c.other_name)}</div>
        ${btns ? `<div class="sch-acts">${btns}</div>` : ''}</div></div>`;
  }

  function renderLists() {
    const day = selected || new Date();
    $('dayTitle').textContent = day.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
    const k = dayKey(day);
    const todays = calls.filter(c => dayKey(new Date(c.start * 1000)) === k && c.status !== 'cancelled');
    $('dayList').innerHTML = todays.length ? todays.map(item).join('') : '<div class="empty-note">No calls this day.</div>';
    const now = nowSec();
    const up = calls.filter(c => live(c) && c.start + c.duration * MIN > now).slice(0, 8);
    $('upList').innerHTML = up.length ? up.map(item).join('') : '<div class="empty-note">Nothing scheduled yet.</div>';
    ov.querySelectorAll('.sch-b').forEach(b => b.addEventListener('click', () => act(b.dataset.act, +b.dataset.id)));
  }

  async function act(what, id) {
    const c = calls.find(x => x.id === id); if (!c) return;
    if (what === 'join') return joinCall(c);
    try {
      await api('api_schedule.php?action=respond', { id, response: what });
      toast(what === 'accept' ? 'Call accepted.' : what === 'decline' ? 'Call declined.' : 'Call cancelled.');
    } catch (e) { toast('Could not update the call.'); }
    refresh();
  }

  function joinCall(c) {
    if (!window.SkillSwapCall) { toast('Video calling is not available.'); return; }
    if (window.SkillSwapCall.isBusy()) { toast('You are already in a call.'); return; }
    closeModal();
    window.SkillSwapCall.start(c.other_id, c.other_name);
  }

  /* ---------- new-call form ---------- */
  async function openForm(preId) {
    let people = [];
    try { people = (await api('api_chat.php?action=people')).people; } catch (e) { toast('Could not load people.'); return; }
    $('sfWith').innerHTML = people.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('') || '<option value="">No other users yet</option>';
    if (preId) $('sfWith').value = String(preId);
    const base = selected && selected > new Date() ? new Date(selected) : new Date(Date.now() + 3600 * 1000);
    if (!(selected && selected > new Date())) base.setMinutes(0, 0, 0); else base.setHours(10, 0, 0, 0);
    const toLocal = d => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    $('sfWhen').min = toLocal(new Date(Date.now() + 5 * 60000));
    $('sfWhen').value = toLocal(base < new Date() ? new Date(Date.now() + 3600 * 1000) : base);
    $('sfTitle').value = '';
    $('schedForm').style.display = 'block';
  }
  $('schedForm').addEventListener('submit', async e => {
    e.preventDefault();
    const to = $('sfWith').value, start = Math.floor(new Date($('sfWhen').value).getTime() / 1000);
    if (!to || !start) { toast('Pick a person and a time.'); return; }
    try {
      await api('api_schedule.php?action=create', { to, start, duration: $('sfDur').value, title: $('sfTitle').value });
      $('schedForm').style.display = 'none';
      toast('Invite sent.');
      selected = new Date(start * 1000); viewY = selected.getFullYear(); viewM = selected.getMonth();
      await refresh();
    } catch (err) { toast(err.message && err.message !== 'error' ? err.message : 'Could not schedule the call.'); }
  });
  $('sfCancel').addEventListener('click', () => { $('schedForm').style.display = 'none'; });
  $('schedNew').addEventListener('click', () => openForm(0));

  /* ---------- open / close ---------- */
  function openModal() {
    const t = new Date(); if (!selected) selected = t;
    viewY = selected.getFullYear(); viewM = selected.getMonth();
    ov.classList.add('show'); renderCal(); renderLists(); refresh();
  }
  function closeModal() { ov.classList.remove('show'); $('schedForm').style.display = 'none'; }
  $('schedClose').addEventListener('click', closeModal);
  ov.addEventListener('click', e => { if (e.target === ov) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && ov.classList.contains('show')) closeModal(); });
  $('calPrev').addEventListener('click', () => { viewM--; if (viewM < 0) { viewM = 11; viewY--; } renderCal(); });
  $('calNext').addEventListener('click', () => { viewM++; if (viewM > 11) { viewM = 0; viewY++; } renderCal(); });
  $('calToday').addEventListener('click', () => { selected = new Date(); viewY = selected.getFullYear(); viewM = selected.getMonth(); renderCal(); renderLists(); });

  const bell = $('schedBtn');
  if (bell) bell.addEventListener('click', openModal);
  const chatBtn = $('scheduleCallBtn');
  if (chatBtn) chatBtn.addEventListener('click', async () => {
    const id = typeof current !== 'undefined' ? current : 0;
    openModal();
    if (id) openForm(id);
  });

  // Lets other pages (e.g. 3-way match cards) open the scheduler for a specific person.
  window.SkillSwapSchedule = { open: async id => { openModal(); if (id) await openForm(id); } };

  /* ---------- data refresh + reminders ---------- */
  async function refresh() {
    try {
      const d = await api('api_schedule.php?action=list');
      serverSkew = d.now - Math.floor(Date.now() / 1000);
      calls = d.calls; loaded = true;
    } catch (e) { return; }
    if (ov.classList.contains('show')) { renderCal(); renderLists(); }
    checkReminders();
  }

  const done = k => store.get('ss_rem_' + ME + '_' + k) === '1';
  const mark = k => store.set('ss_rem_' + ME + '_' + k, '1');

  function notify(title, body) {
    try { if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body }); } catch (e) {}
  }

  function showBanner(c, text) {
    const id = 'bn' + c.id;
    if ($(id)) { $(id).querySelector('span').textContent = text; return; }
    const d = document.createElement('div');
    d.className = 'sch-banner'; d.id = id;
    d.innerHTML = `<span></span><button type="button" class="sch-b join">📹 Join</button><button type="button" class="sch-x" aria-label="Dismiss">✕</button>`;
    d.querySelector('span').textContent = text;
    d.querySelector('.join').addEventListener('click', () => { d.remove(); joinCall(c); });
    d.querySelector('.sch-x').addEventListener('click', () => { d.remove(); mark('dismiss_' + c.id); });
    banner.appendChild(d);
  }

  function checkReminders() {
    if (!loaded) return;
    const now = nowSec();
    let pending = 0, soon = 0;
    calls.forEach(c => {
      const end = c.start + c.duration * MIN, left = c.start - now;
      if (c.status === 'pending' && !c.mine && end > now) {
        pending++;
        if (!done('inv_' + c.id)) { mark('inv_' + c.id); toast(c.other_name + ' invited you to a call on ' + fmtDate(c.start) + ' at ' + fmtTime(c.start)); notify('Call invitation', c.other_name + ' · ' + fmtDate(c.start) + ' ' + fmtTime(c.start)); }
      }
      if (c.status === 'accepted' && end > now) {
        if (left <= 60 * MIN) soon++;
        if (left <= 10 * MIN) {
          const text = left > 0 ? `📞 Call with ${c.other_name} starts in ${Math.max(1, Math.ceil(left / 60))} min` : `📞 Your call with ${c.other_name} is on now`;
          if (!done('dismiss_' + c.id)) showBanner(c, text);
          if (!done('r10_' + c.id)) { mark('r10_' + c.id); notify('Call reminder', text); toast(text.replace('📞 ', '')); }
        }
      } else if ($('bn' + c.id)) $('bn' + c.id).remove();
    });
    const n = pending + soon;
    const badge = $('schedCount');
    if (badge) { badge.style.display = n ? 'inline-block' : 'none'; badge.textContent = n; }
    if (bell) bell.classList.toggle('ring', soon > 0 || pending > 0);
  }

  // Ask once for browser notifications (only after the user opens the scheduler = a real click).
  if (bell) bell.addEventListener('click', () => { try { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission(); } catch (e) {} });

  refresh();
  setInterval(refresh, 20000);
  setInterval(checkReminders, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
})();
