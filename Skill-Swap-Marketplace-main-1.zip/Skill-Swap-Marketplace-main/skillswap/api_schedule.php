<?php
// JSON API for scheduled calls. Times are stored as Unix timestamps (UTC) so every user sees the
// right moment in their own timezone.
require_once 'config.php';
header('Content-Type: application/json');

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'auth']);
    exit();
}
$me = (int)$_SESSION['user_id'];
$action = $_GET['action'] ?? '';
session_write_close();

$conn->query("CREATE TABLE IF NOT EXISTS scheduled_calls (
    id INT AUTO_INCREMENT PRIMARY KEY, creator_id INT NOT NULL, invitee_id INT NOT NULL,
    title VARCHAR(120) NOT NULL DEFAULT '', start_ts BIGINT NOT NULL, duration_min SMALLINT NOT NULL DEFAULT 30,
    status ENUM('pending','accepted','declined','cancelled') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_creator (creator_id, start_ts), INDEX idx_invitee (invitee_id, start_ts),
    FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (invitee_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB");

function fail($code, $msg) { http_response_code($code); echo json_encode(['error' => $msg]); exit(); }

if ($action === 'list') {
    // Everything from 30 days ago onward that involves me (small, fits one response).
    $from = time() - 30 * 86400;
    $st = $conn->prepare("
        SELECT c.id, c.creator_id, c.invitee_id, c.title, c.start_ts, c.duration_min, c.status,
               uc.name AS creator_name, ui.name AS invitee_name
        FROM scheduled_calls c
        JOIN users uc ON uc.id = c.creator_id JOIN users ui ON ui.id = c.invitee_id
        WHERE (c.creator_id = ? OR c.invitee_id = ?) AND c.start_ts >= ?
        ORDER BY c.start_ts ASC LIMIT 300");
    $st->bind_param("iii", $me, $me, $from);
    $st->execute();
    $out = [];
    foreach ($st->get_result() as $r) {
        $mine = (int)$r['creator_id'] === $me;
        $out[] = [
            'id' => (int)$r['id'], 'title' => $r['title'], 'start' => (int)$r['start_ts'],
            'duration' => (int)$r['duration_min'], 'status' => $r['status'], 'mine' => $mine,
            'other_id' => $mine ? (int)$r['invitee_id'] : (int)$r['creator_id'],
            'other_name' => $mine ? $r['invitee_name'] : $r['creator_name'],
        ];
    }
    echo json_encode(['calls' => $out, 'now' => time()]);
    exit();
}

if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $to    = (int)($_POST['to'] ?? 0);
    $start = (int)($_POST['start'] ?? 0);
    $dur   = (int)($_POST['duration'] ?? 30);
    $title = mb_substr(trim($_POST['title'] ?? ''), 0, 120);
    if ($to === $me || $to <= 0) fail(400, 'Pick someone to call.');
    if ($start < time() + 60) fail(400, 'Please choose a time in the future.');
    if ($start > time() + 365 * 86400) fail(400, 'That date is too far ahead.');
    if ($dur < 10 || $dur > 180) $dur = 30;
    $chk = $conn->prepare("SELECT id FROM users WHERE id = ?");
    $chk->bind_param("i", $to);
    $chk->execute();
    if (!$chk->get_result()->num_rows) fail(404, 'No such user.');
    $ins = $conn->prepare("INSERT INTO scheduled_calls (creator_id, invitee_id, title, start_ts, duration_min) VALUES (?, ?, ?, ?, ?)");
    $ins->bind_param("iisii", $me, $to, $title, $start, $dur);
    $ins->execute();
    echo json_encode(['ok' => true, 'id' => $conn->insert_id]);
    exit();
}

if ($action === 'respond' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id  = (int)($_POST['id'] ?? 0);
    $act = $_POST['response'] ?? '';
    if (!in_array($act, ['accept', 'decline', 'cancel'], true)) fail(400, 'invalid');
    if ($act === 'cancel') {   // either person can cancel a call that is still open
        $st = $conn->prepare("UPDATE scheduled_calls SET status='cancelled' WHERE id = ? AND (creator_id = ? OR invitee_id = ?) AND status IN ('pending','accepted')");
        $st->bind_param("iii", $id, $me, $me);
    } else {                   // only the invitee can accept/decline
        $new = $act === 'accept' ? 'accepted' : 'declined';
        $st = $conn->prepare("UPDATE scheduled_calls SET status = ? WHERE id = ? AND invitee_id = ? AND status = 'pending'");
        $st->bind_param("sii", $new, $id, $me);
    }
    $st->execute();
    echo json_encode(['ok' => $st->affected_rows > 0]);
    exit();
}

fail(400, 'bad action');
