/* Skill Swap video calls — WebRTC (peer-to-peer video) + signaling through api_call.php (polling).
   Self-contained: adds a 📹 button to the open chat and a call overlay. Does not alter chat logic. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }]
    .concat(window.SKILLSWAP_TURN || []) }; // optional TURN servers, see README
  const toast = m => (typeof showToast === 'function' ? showToast(m) : alert(m));
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  async function call(url, data) {
    const opts = data ? { method: 'POST', body: new URLSearchParams(data) } : {};
    const r = await fetch(url, opts);
    if (!r.ok) throw new Error('http ' + r.status);
    return r.json();
  }
  const signal = (to, type, payload) =>
    call('api_call.php?action=send', { to, type, payload: payload ? JSON.stringify(payload) : '' }).catch(() => {});

  let cursor = null, pollTimer = null;
  let peer = 0, peerName = '', pc = null, localStream = null, pendingIce = [];
  let state = 'idle'; // idle | calling | ringing | connecting | live
  let ringTimeout = null, incoming = null;

  /* ---------- UI ---------- */
  const ov = document.createElement('div');
  ov.id = 'callOverlay';
  ov.innerHTML = `
    <div class="call-box">
      <div class="call-title" id="callTitle"></div>
      <div class="call-stage">
        <video id="remoteVideo" autoplay playsinline></video>
        <video id="localVideo" autoplay playsinline muted></video>
        <div class="call-wait" id="callWait"></div>
      </div>
      <div class="call-controls">
        <button id="callAccept" class="cc cc-ok" style="display:none">Accept</button>
        <button id="callMic" class="cc" style="display:none">Mute</button>
        <button id="callCam" class="cc" style="display:none">Camera off</button>
        <button id="callEnd" class="cc cc-end">Hang up</button>
      </div>
    </div>`;
  document.body.appendChild(ov);

  const setUI = (title, wait) => { $('callTitle').textContent = title; $('callWait').textContent = wait || ''; $('callWait').style.display = wait ? 'flex' : 'none'; };
  function show(on) { ov.classList.toggle('show', on); }
  function controls({ accept, media }) {
    $('callAccept').style.display = accept ? '' : 'none';
    $('callMic').style.display = $('callCam').style.display = media ? '' : 'none';
  }

  // The button lives in the chat header (user_page.php); create it here only if it is missing.
  let vbtn = $('videoCallBtn');
  if (!vbtn) {
    const head = document.querySelector('.chat-head');
    if (head) {
      vbtn = document.createElement('button');
      vbtn.type = 'button'; vbtn.id = 'videoCallBtn'; vbtn.className = 'vc-btn'; vbtn.textContent = '📹 Video call';
      head.insertBefore(vbtn, $('chatStatus'));
    }
  }
  if (vbtn) vbtn.addEventListener('click', () => {
    const id = typeof current !== 'undefined' ? current : 0;
    if (id) startCall(id, $('chatName').textContent); else toast('Open a conversation first.');
  });

  /* ---------- media / peer connection ---------- */
  async function getMedia() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast('Video calls need a secure (https) connection and a supported browser.'); return false;
    }
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      $('localVideo').srcObject = localStream;
      return true;
    } catch (e) {
      toast('Could not access camera/microphone. Please allow permission and try again.'); return false;
    }
  }

  function makePC() {
    pc = new RTCPeerConnection(ICE);
    pendingIce = [];
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
    pc.ontrack = e => { $('remoteVideo').srcObject = e.streams[0]; };
    pc.onicecandidate = e => { if (e.candidate) signal(peer, 'ice', e.candidate); };
    pc.onconnectionstatechange = () => {
      if (!pc) return;
      if (pc.connectionState === 'connected') { state = 'live'; setUI('In call with ' + peerName, ''); controls({ media: true }); }
      if (pc.connectionState === 'failed') { toast('Call connection failed.'); endCall(true); }
    };
  }

  async function addIce(c) {
    if (pc && pc.remoteDescription) { try { await pc.addIceCandidate(c); } catch (e) {} }
    else pendingIce.push(c);
  }
  async function flushIce() { for (const c of pendingIce) { try { await pc.addIceCandidate(c); } catch (e) {} } pendingIce = []; }

  /* ---------- call flow ---------- */
  async function startCall(id, name) {
    if (state !== 'idle') return;
    if (!(await getMedia())) return;
    peer = id; peerName = name; state = 'calling';
    setUI('Calling ' + name + '…', 'Waiting for ' + name + ' to answer…');
    controls({}); show(true);
    await signal(peer, 'invite');
    ringTimeout = setTimeout(() => { if (state === 'calling') { toast(name + ' did not answer.'); endCall(true); } }, 40000);
  }

  async function acceptCall() {
    if (state !== 'ringing' || !incoming) return;
    peer = incoming.from; peerName = incoming.name;
    if (!localStream && !(await getMedia())) { signal(peer, 'decline'); cleanup(); return; }
    state = 'connecting'; setUI('Connecting…', 'Connecting…'); controls({});
    makePC();
    signal(peer, 'accept');
  }

  function endCall(notify) {
    if (notify && peer && state !== 'idle') signal(peer, state === 'ringing' ? 'decline' : 'hangup');
    cleanup();
  }

  function cleanup() {
    clearTimeout(ringTimeout);
    if (pc) { pc.ontrack = pc.onicecandidate = pc.onconnectionstatechange = null; pc.close(); pc = null; }
    if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
    $('remoteVideo').srcObject = null; $('localVideo').srcObject = null;
    $('callMic').textContent = 'Mute'; $('callCam').textContent = 'Camera off';
    peer = 0; incoming = null; pendingIce = []; state = 'idle';
    show(false);
  }

  async function handle(s) {
    const payload = s.payload ? JSON.parse(s.payload) : null;
    switch (s.type) {
      case 'invite':
        if (s.age > 45) return;                              // stale
        if (state === 'calling' && s.from === peer) {         // both sides pressed call at once (e.g. scheduled call)
          if (Number(document.body.dataset.me) < peer) return; // lower id stays the caller
          clearTimeout(ringTimeout); incoming = s; state = 'ringing'; acceptCall(); return; // other id answers
        }
        if (state !== 'idle') { signal(s.from, 'busy'); return; }
        incoming = s; peer = s.from; peerName = s.name; state = 'ringing';
        setUI(s.name + ' is calling you…', '📞 Incoming video call'); controls({ accept: true }); show(true);
        ringTimeout = setTimeout(() => { if (state === 'ringing') cleanup(); }, 45000);
        break;
      case 'accept':
        if (state !== 'calling' || s.from !== peer) return;
        clearTimeout(ringTimeout); state = 'connecting'; setUI('Connecting…', 'Connecting…');
        makePC();
        await pc.setLocalDescription(await pc.createOffer());
        signal(peer, 'offer', pc.localDescription);
        break;
      case 'offer':
        if (state !== 'connecting' || s.from !== peer || !pc) return;
        await pc.setRemoteDescription(payload);
        await flushIce();
        await pc.setLocalDescription(await pc.createAnswer());
        signal(peer, 'answer', pc.localDescription);
        break;
      case 'answer':
        if (!pc || s.from !== peer) return;
        await pc.setRemoteDescription(payload); await flushIce();
        break;
      case 'ice':
        if (s.from === peer && payload) addIce(payload);
        break;
      case 'decline': case 'busy': case 'hangup':
        if (s.from !== peer || state === 'idle') return;
        if (s.type === 'decline') toast(peerName + ' declined the call.');
        if (s.type === 'busy') toast(peerName + ' is on another call.');
        if (s.type === 'hangup' && state !== 'ringing') toast('Call ended.');
        cleanup();
        break;
    }
  }

  /* ---------- polling for signals ---------- */
  let polling = false;
  async function poll() {
    if (polling) return; polling = true;
    try {
      if (cursor === null) cursor = (await call('api_call.php?action=init')).last;
      const d = await call('api_call.php?action=poll&since=' + cursor);
      for (const s of d.signals) { cursor = Math.max(cursor, s.id); try { await handle(s); } catch (e) { console.error(e); } }
    } catch (e) { /* offline / logged out: try again next tick */ }
    polling = false;
  }
  function schedule() { clearInterval(pollTimer); pollTimer = setInterval(poll, state !== 'idle' ? 700 : (document.hidden ? 4000 : 1500)); }
  setInterval(schedule, 2000); schedule(); poll();

  /* ---------- buttons ---------- */
  $('callAccept').addEventListener('click', acceptCall);
  $('callEnd').addEventListener('click', () => endCall(true));
  $('callMic').addEventListener('click', e => {
    if (!localStream) return; const t = localStream.getAudioTracks()[0]; if (!t) return;
    t.enabled = !t.enabled; e.target.textContent = t.enabled ? 'Mute' : 'Unmute';
  });
  $('callCam').addEventListener('click', e => {
    if (!localStream) return; const t = localStream.getVideoTracks()[0]; if (!t) return;
    t.enabled = !t.enabled; e.target.textContent = t.enabled ? 'Camera off' : 'Camera on';
  });
  window.SkillSwapCall = { start: startCall, isBusy: () => state !== 'idle' }; // used by the scheduler
  window.addEventListener('beforeunload', () => { if (peer && state !== 'idle') navigator.sendBeacon && navigator.sendBeacon('api_call.php?action=send', new URLSearchParams({ to: peer, type: 'hangup', payload: '' })); });
})();
