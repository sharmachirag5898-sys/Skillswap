const $ = id => document.getElementById(id);
const ME = parseInt(document.body.dataset.me, 10);
const palette = ["#D6334B","#2E6B5E","#B98A2E","#3B5CA8","#7A4FB5","#C25A2C"];
const exampleSkills = [
  { title:"Guitar basics for beginners", teacherName:"Ananya R.", category:"Music", wants:"Excel / spreadsheets", example:true },
  { title:"Python for data analysis", teacherName:"Rohit S.", category:"Coding", wants:"Photography basics", example:true },
  { title:"Public speaking & debate", teacherName:"Meera K.", category:"Soft Skills", wants:"Video editing", example:true },
  { title:"Sketching & ink illustration", teacherName:"Farhan A.", category:"Art", wants:"Spoken French", example:true },
  { title:"Badminton fundamentals", teacherName:"Divya N.", category:"Sports", wants:"Resume & LinkedIn help", example:true },
  { title:"Excel & pivot tables", teacherName:"Karthik V.", category:"Business", wants:"Guitar basics", example:true },
];
let query = "", activeCategory = "All", livePosts = [];

const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const initial = n => (n || '?').trim().charAt(0).toUpperCase();
function showToast(msg){ const t=$('toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2200); }
function timeAgo(ts){
  const s = Math.max(1, Math.floor((Date.now()-ts)/1000));
  if (s<60) return s+"s ago"; const m=Math.floor(s/60); if (m<60) return m+"m ago";
  const h=Math.floor(m/60); if (h<24) return h+"h ago"; return Math.floor(h/24)+"d ago";
}
async function api(url, opts){
  const r = await fetch(url, Object.assign({ credentials:'same-origin' }, opts));
  if (r.status === 401) { location.href = 'index.php'; throw new Error('auth'); }
  return r.json();
}
const post = (url, data) => api(url, { method:'POST', body:new URLSearchParams(data) });

/* ---------------- Explore board ---------------- */
const currentList = () => livePosts.length ? livePosts : exampleSkills;

function initChips(){
  const cats = ["All", ...Array.from(new Set(currentList().map(s => s.category)))];
  $('chips').innerHTML = cats.map(c => `<button class="chip ${c===activeCategory?'active':''}" data-cat="${esc(c)}">${esc(c)}</button>`).join("");
  $('chips').querySelectorAll('.chip').forEach(ch => ch.addEventListener('click', () => { activeCategory = ch.dataset.cat; initChips(); renderGrid(); }));
}

function renderGrid(){
  const list = currentList();
  $('exploreSub').textContent = livePosts.length
    ? livePosts.length + " live listing" + (livePosts.length===1?"":"s") + " on the board"
    : "No live posts yet — showing example listings. Be the first to post!";
  const q = query.toLowerCase();
  const filtered = list.filter(s =>
    (s.title + s.teacherName + s.category + (s.wants||'')).toLowerCase().includes(q) &&
    (activeCategory === "All" || s.category === activeCategory));
  if (!filtered.length){ $('masonry').innerHTML = `<div class="noresults">No skills match "${esc(query)}". Try a different search or category.</div>`; return; }
  $('masonry').innerHTML = filtered.map((s,i) => {
    const color = palette[i % palette.length];
    const tag = s.example ? `<span class="example-tag">Example</span>` : (s.ts ? `<span class="example-tag" style="color:var(--ok)">${timeAgo(s.ts)}</span>` : "");
    const btn = (!s.example && !s.mine) ? `<button class="msgbtn" data-id="${s.userId}" data-name="${esc(s.teacherName)}">Message</button>` : "";
    return `<div class="pcard"><div class="thumb" style="background:${color}">${esc(s.category)}</div>
      <div class="pbody"><div class="pcat">${esc(s.category)} ${tag}</div><h3>${esc(s.title)}</h3>
      ${s.desc ? `<div class="pdesc">${esc(s.desc)}</div>` : ""}
      <div class="pwants">Wants: ${esc(s.wants)}</div>
      <div class="pfoot"><span class="avatar" style="background:${color}22;color:${color}">${esc(initial(s.teacherName))}</span>${esc(s.mine ? 'You' : s.teacherName)}${btn}</div></div></div>`;
  }).join("");
  $('masonry').querySelectorAll('.msgbtn').forEach(b => b.addEventListener('click', () => openChat(+b.dataset.id, b.dataset.name)));
}

async function loadPosts(){
  try { livePosts = (await api('api.php?action=posts')).posts; } catch(e) { return; }
  initChips(); renderGrid();
}

function runSearch(val){
  query = val; activeCategory = "All"; initChips(); renderGrid();
  $('explore').scrollIntoView({ behavior:'smooth' });
}
$('heroSearchBtn').addEventListener('click', () => runSearch($('heroSearchInput').value));
$('heroSearchInput').addEventListener('keypress', e => { if (e.key==='Enter') runSearch(e.target.value); });
$('navSearchInput').addEventListener('input', e => { query = e.target.value; renderGrid(); });

/* ---------------- Stats + ticker ---------------- */
async function loadStats(){
  try {
    const d = await api('api.php?action=stats');
    $('statStudents').textContent = d.students.toLocaleString();
    $('statSkills').textContent   = d.skills.toLocaleString();
    $('statSwaps').textContent    = d.chats.toLocaleString();
    ['liveStudents','liveSkills','liveSwaps'].forEach(id => $(id).textContent = "● live");
    const items = d.feed.map(f => `<span>${esc(f.text)}</span>`);
    $('tickerTrack').innerHTML = items.length ? [...items, ...items].join("") : `<span>Be the first to post a skill — activity shows up here live.</span>`;
  } catch(e) {}
}

/* ---------------- Post a skill ---------------- */
const show = id => $(id).classList.add('show');
const hide = id => $(id).classList.remove('show');
$('postSkillBtn').addEventListener('click', () => show('postOverlay'));
$('closePost').addEventListener('click', () => hide('postOverlay'));
$('postOverlay').addEventListener('click', e => { if (e.target.id==='postOverlay') hide('postOverlay'); });
$('postForm').addEventListener('submit', async e => {
  e.preventDefault();
  try {
    const r = await post('api.php?action=post', {
      title: $('sTitle').value, category: $('sCategory').value, wants: $('sWants').value, desc: $('sDesc').value });
    if (r.error) throw new Error(r.error);
    hide('postOverlay'); $('postForm').reset();
    showToast("Posted — live on the board now.");
    await loadPosts(); loadStats();
    $('explore').scrollIntoView({ behavior:'smooth' });
  } catch(err) { showToast("Couldn't post. Please try again."); }
});

/* ---------------- Profile + matching ---------------- */
async function saveProfileAndMatch(){
  const teach = $('canTeach').value, learn = $('wantLearn').value;
  if (!teach.trim() && !learn.trim()) { showToast("Add at least one skill."); return; }
  try {
    const r = await post('api.php?action=profile', { teach, learn });
    $('canTeach').value = $('pTeach').value = r.teach.join(', ');
    $('wantLearn').value = $('pLearn').value = r.learn.join(', ');
    $('matchStatus').textContent = "Saved ✓ — matching against everyone else on the board.";
    loadMatches(); loadPosts(); loadStats();
  } catch(e) { $('matchStatus').textContent = "Couldn't save. Please try again."; }
}
$('findMatchBtn').addEventListener('click', saveProfileAndMatch);
$('profForm').addEventListener('submit', async e => {
  e.preventDefault();
  $('canTeach').value = $('pTeach').value;
  $('wantLearn').value = $('pLearn').value;
  await saveProfileAndMatch();
  hide('profOverlay');
  $('match').scrollIntoView({ behavior:'smooth' });
});
$('openProfileBtn').addEventListener('click', () => show('profOverlay'));
$('closeProf').addEventListener('click', () => hide('profOverlay'));
$('profOverlay').addEventListener('click', e => { if (e.target.id==='profOverlay') hide('profOverlay'); });

async function loadMatches(){
  let d; try { d = await api('api.php?action=matches'); } catch(e) { return; }
  const box = $('matchesResult');
  if (!d.matches.length) { box.innerHTML = `<div class="empty-note">No overlapping matches yet — matches appear live as more people save profiles.</div>`; return; }
  box.innerHTML = d.matches.map(m => `
    <div class="match-hit" data-id="${m.id}" data-name="${esc(m.name)}">
      <span class="avatar">${esc(initial(m.name))}<span class="pres ${m.online?'on':''}"></span></span>
      <div class="mh-info"><div class="mh-name">${esc(m.name)}</div>
      <div class="mh-sub">Teaches ${esc((m.theyTeach.length?m.theyTeach:m.teach).join(', ')||'—')} · wants ${esc((m.theyWant.length?m.theyWant:m.learn).join(', ')||'—')}</div></div>
      <div class="mh-score">${m.score} overlap</div></div>`).join("");
  box.querySelectorAll('.match-hit').forEach(el => el.addEventListener('click', () => openChat(+el.dataset.id, el.dataset.name)));
}

/* ---------------- Chat (polls the database every ~1.5s) ---------------- */
let current = 0, lastId = 0, pollTimer = null;
const names = {};
const fmt = ts => new Date(ts * 1000).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });

function showConvView(){
  current = 0; clearInterval(pollTimer);
  $('threadView').style.display = 'none'; $('convView').style.display = 'block';
  loadConversations();
}

async function loadConversations(){
  let d; try { d = await api('api_chat.php?action=people'); } catch(e) { return; }
  d.people.forEach(p => names[p.id] = p.name);
  const unread = d.people.reduce((n,p) => n + p.unread, 0);
  const badge = $('unreadBadge');
  badge.style.display = unread ? 'inline' : 'none'; badge.textContent = unread;
  if (current) return;
  const convs = d.people.filter(p => p.last);
  $('convList').innerHTML = convs.length ? convs.map(p => `
    <div class="match-hit" data-id="${p.id}" data-name="${esc(p.name)}">
      <span class="avatar">${esc(initial(p.name))}<span class="pres ${p.online?'on':''}"></span></span>
      <div class="mh-info"><div class="mh-name">${esc(p.name)}</div><div class="mh-sub">${esc(p.last)}</div></div>
      ${p.unread ? `<div class="mh-score">${p.unread} new</div>` : ''}</div>`).join("")
    : `<div class="empty-note">No conversations yet.</div>`;
  $('convList').querySelectorAll('.match-hit').forEach(el => el.addEventListener('click', () => openChat(+el.dataset.id, el.dataset.name)));
}

function addMessages(list){
  const box = $('messages');
  const stick = box.scrollTop + box.clientHeight >= box.scrollHeight - 60;
  let added = false, mine = false;
  list.forEach(m => {
    if (m.id <= lastId) return;
    const d = document.createElement('div');
    d.className = 'msg ' + (m.mine ? 'me' : 'them');
    d.innerHTML = esc(m.body) + `<div class="t">${fmt(m.ts)}</div>`;
    box.appendChild(d); lastId = m.id; added = true; if (m.mine) mine = true;
  });
  if (added && (stick || mine)) box.scrollTop = box.scrollHeight;
}

async function poll(){
  if (!current) return;
  const target = current;
  try {
    const d = await api(`api_chat.php?action=poll&with=${target}&since=${lastId}`);
    if (target !== current) return;
    addMessages(d.messages);
    $('chatStatus').textContent = d.online ? '● online' : 'offline';
  } catch(e) {}
}

function schedulePoll(){
  clearInterval(pollTimer);
  pollTimer = setInterval(poll, document.hidden ? 5000 : 1500);
}

async function openChat(id, name){
  current = id; lastId = 0; names[id] = name;
  $('chatName').textContent = name;
  $('chatAvatar').textContent = initial(name);
  $('messages').innerHTML = '';
  $('chatCard').classList.add('show');
  $('convView').style.display = 'none'; $('threadView').style.display = 'block';
  $('chatCard').scrollIntoView({ behavior:'smooth' });
  await poll(); schedulePoll(); $('msgInput').focus();
}

async function sendMessage(){
  const input = $('msgInput'), text = input.value.trim();
  if (!text || !current) return;
  input.value = '';
  try { await post('api_chat.php?action=send', { to: current, body: text }); poll(); }
  catch(e){ input.value = text; showToast("Message failed to send."); }
}
$('sendBtn').addEventListener('click', sendMessage);
$('msgInput').addEventListener('keypress', e => { if (e.key==='Enter') sendMessage(); });
$('backBtn').addEventListener('click', showConvView);
$('inboxLink').addEventListener('click', e => {
  e.preventDefault();
  $('chatCard').classList.add('show');
  if (!current) showConvView();
  $('chatCard').scrollIntoView({ behavior:'smooth' });
});
document.addEventListener('visibilitychange', () => { if (current) { schedulePoll(); if (!document.hidden) poll(); } });

/* ---------------- Boot ---------------- */
initChips(); renderGrid();
loadPosts(); loadStats(); loadMatches(); loadConversations();
// Keep everything live for every user on every device
setInterval(loadPosts, 8000);
setInterval(loadStats, 8000);
setInterval(loadMatches, 8000);
setInterval(loadConversations, 4000);
