<?php
// JSON API for 3-way skill swaps. Read-only: uses the existing users / skills / user_skills tables.
require_once 'config.php';
require_once 'triangle_lib.php';
header('Content-Type: application/json');

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'auth']);
    exit();
}
$me = (int)$_SESSION['user_id'];
session_write_close();

$people = [];
foreach ($conn->query("SELECT id, name, (last_seen IS NOT NULL AND last_seen > NOW() - INTERVAL 30 SECOND) AS online FROM users LIMIT 1000") as $u) {
    $people[(int)$u['id']] = ['name' => $u['name'], 'online' => (bool)$u['online'], 'offer' => [], 'want' => []];
}
foreach ($conn->query("SELECT us.user_id, us.type, s.name FROM user_skills us JOIN skills s ON s.id = us.skill_id") as $r) {
    $uid = (int)$r['user_id'];
    if (isset($people[$uid])) $people[$uid][$r['type']][] = $r['name'];
}

echo json_encode([
    'hasDirect' => hasDirectSwap($me, $people),   // someone who can swap with me one-to-one
    'triangles' => findTriangles($me, $people, 20),
]);
