<?php
// JSON API for chat. All state lives in MySQL, so any device/user sees the same data.
require_once 'config.php';
header('Content-Type: application/json');

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'auth']);
    exit();
}
$me = (int)$_SESSION['user_id'];
$action = $_GET['action'] ?? '';

// Release the session lock so polling requests from several tabs don't block each other.
session_write_close();

// Presence heartbeat
$conn->query("UPDATE users SET last_seen = NOW() WHERE id = $me");

if ($action === 'people') {
    $sql = "
        SELECT u.id, u.name,
               (u.last_seen IS NOT NULL AND u.last_seen > NOW() - INTERVAL 30 SECOND) AS online,
               (SELECT COUNT(*) FROM messages m WHERE m.sender_id = u.id AND m.receiver_id = ? AND m.is_read = 0) AS unread,
               (SELECT m.body FROM messages m WHERE (m.sender_id = u.id AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = u.id) ORDER BY m.id DESC LIMIT 1) AS last_body,
               (SELECT MAX(m.id) FROM messages m WHERE (m.sender_id = u.id AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = u.id)) AS last_id
        FROM users u WHERE u.id <> ?
        ORDER BY last_id IS NULL, last_id DESC, u.name ASC LIMIT 200";
    $st = $conn->prepare($sql);
    $st->bind_param("iiiiii", $me, $me, $me, $me, $me, $me);
    $st->execute();
    $out = [];
    foreach ($st->get_result() as $r) {
        $out[] = ['id' => (int)$r['id'], 'name' => $r['name'], 'online' => (bool)$r['online'],
                  'unread' => (int)$r['unread'], 'last' => $r['last_body'] ?? ''];
    }
    echo json_encode(['people' => $out]);
    exit();
}

if ($action === 'poll') {
    $with  = (int)($_GET['with'] ?? 0);
    $since = (int)($_GET['since'] ?? 0);

    $st = $conn->prepare("
        SELECT id, sender_id, body, UNIX_TIMESTAMP(created_at) AS ts
        FROM messages
        WHERE id > ? AND ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
        ORDER BY id ASC LIMIT 200");
    $st->bind_param("iiiii", $since, $me, $with, $with, $me);
    $st->execute();
    $msgs = [];
    foreach ($st->get_result() as $r) {
        $msgs[] = ['id' => (int)$r['id'], 'mine' => (int)$r['sender_id'] === $me, 'body' => $r['body'], 'ts' => (int)$r['ts']];
    }

    // Mark what they sent me as read
    $rd = $conn->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0");
    $rd->bind_param("ii", $with, $me);
    $rd->execute();

    $on = $conn->prepare("SELECT (last_seen IS NOT NULL AND last_seen > NOW() - INTERVAL 30 SECOND) AS online FROM users WHERE id = ?");
    $on->bind_param("i", $with);
    $on->execute();
    $row = $on->get_result()->fetch_assoc();

    echo json_encode(['messages' => $msgs, 'online' => (bool)($row['online'] ?? false)]);
    exit();
}

if ($action === 'send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $to   = (int)($_POST['to'] ?? 0);
    $body = trim($_POST['body'] ?? '');
    if ($body === '' || $to === $me || mb_strlen($body) > 2000) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid']);
        exit();
    }
    $chk = $conn->prepare("SELECT id FROM users WHERE id = ?");
    $chk->bind_param("i", $to);
    $chk->execute();
    if (!$chk->get_result()->num_rows) {
        http_response_code(404);
        echo json_encode(['error' => 'no such user']);
        exit();
    }
    $ins = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, body) VALUES (?, ?, ?)");
    $ins->bind_param("iis", $me, $to, $body);
    $ins->execute();
    echo json_encode(['ok' => true, 'id' => $conn->insert_id]);
    exit();
}

http_response_code(400);
echo json_encode(['error' => 'bad action']);
