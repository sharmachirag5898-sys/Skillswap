<?php
require_once 'config.php';
requireLogin();
$me = (int)$_SESSION['user_id'];

$teach = []; $learn = [];
$st = $conn->prepare("SELECT s.name, us.type FROM user_skills us JOIN skills s ON s.id = us.skill_id WHERE us.user_id = ?");
$st->bind_param("i", $me);
$st->execute();
foreach ($st->get_result() as $r) {
    if ($r['type'] === 'offer') $teach[] = $r['name']; else $learn[] = $r['name'];
}
$teachStr = implode(', ', $teach);
$learnStr = implode(', ', $learn);
$isAdmin = ($_SESSION['role'] ?? '') === 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Skill Swap — Trade what you know</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="skillswap.css?v=<?= filemtime(__DIR__ . "/skillswap.css") ?>">
</head>
<body data-me="<?= $me ?>">

<nav>
  <div class="navrow">
    <a class="logo" href="user_page.php"><span class="dot">SS</span> Skill Swap</a>
    <div class="navsearch">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
      <input id="navSearchInput" type="search" placeholder="Search skills, teachers, categories…">
    </div>
    <div class="navlinks">
      <a href="#explore">Explore</a>
      <a href="#match">Find a match</a>
      <a href="#chatCard" id="inboxLink">Messages<span class="badge" id="unreadBadge" style="display:none">0</span></a>
      <a href="#how">How it works</a>
      <?php if ($isAdmin): ?><a href="admin_page.php">Admin</a><?php endif; ?>
    </div>
    <div class="navauth">
      <span class="whoid"><span class="avatar" style="width:26px;height:26px;font-size:0.7rem"><?= e(mb_strtoupper(mb_substr($_SESSION['name'], 0, 1))) ?></span> <?= e($_SESSION['name']) ?></span>
      <button type="button" class="sch-bell" id="schedBtn" title="Scheduled calls &amp; reminders" aria-label="Scheduled calls and reminders">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 01-3.4 0"/></svg>
        <span class="sch-count" id="schedCount" style="display:none">0</span>
      </button>
      <button class="btn btn-accent" id="openProfileBtn">My profile</button>
      <a class="btn btn-ghost" href="logout.php">Log out</a>
    </div>
  </div>
</nav>

<section class="hero">
  <div class="wrap">
    <h1>Trade what you know.<br><em>Learn</em> what you don't.</h1>
    <p>A skill-swap marketplace built for campus — no money changes hands, just knowledge for knowledge.</p>
    <div class="herosearch">
      <input id="heroSearchInput" type="search" placeholder="Try “guitar”, “Python”, “public speaking”…">
      <button id="heroSearchBtn">Search</button>
    </div>
    <div class="stats">
      <div class="stat"><div class="num" id="statStudents">0</div><div class="lbl">students on board</div><div class="live" id="liveStudents"></div></div>
      <div class="stat"><div class="num" id="statSkills">0</div><div class="lbl">skills listed</div><div class="live" id="liveSkills"></div></div>
      <div class="stat"><div class="num" id="statSwaps">0</div><div class="lbl">chats started</div><div class="live" id="liveSwaps"></div></div>
    </div>
  </div>
</section>

<div class="ticker-wrap"><div class="ticker-track" id="tickerTrack"></div></div>

<section class="match" id="match">
  <div class="match-card">
    <h2>Find your match — for real</h2>
    <p class="sub">Save your skills and you'll be matched live against everyone else on the board.</p>
    <div class="match-grid">
      <div class="fld"><label>I can teach</label><input id="canTeach" placeholder="Guitar, Excel" value="<?= e($teachStr) ?>"></div>
      <div class="fld"><label>I want to learn</label><input id="wantLearn" placeholder="Python, Photography" value="<?= e($learnStr) ?>"></div>
      <button id="findMatchBtn">Save &amp; find matches</button>
    </div>
    <div class="match-status" id="matchStatus"></div>
    <div class="matches-result" id="matchesResult"><div class="empty-note">Save your skills above to see live matches.</div></div>
  </div>

  <div class="match-card chat-card" id="chatCard">
    <!-- Conversation list -->
    <div id="convView">
      <h2>Messages</h2>
      <p class="sub" style="color:var(--ink-soft);font-size:.9rem;margin:0 0 14px">Your conversations. Start a new one from a match or a skill card.</p>
      <div class="matches-result" id="convList"><div class="empty-note">No conversations yet.</div></div>
    </div>
    <!-- Open thread -->
    <div id="threadView" style="display:none">
      <div class="chat-head">
        <button class="back" id="backBtn">← Back</button>
        <span class="avatar" id="chatAvatar"></span><strong id="chatName"></strong>
        <button type="button" class="vc-btn sch-chat-btn" id="scheduleCallBtn" title="Schedule a call">📅 Schedule</button>
        <button type="button" class="vc-btn" id="videoCallBtn" title="Start video call">📹 Video call</button>
        <small id="chatStatus"></small>
      </div>
      <div class="messages" id="messages"></div>
      <div class="chat-input">
        <input id="msgInput" placeholder="Write a message…" maxlength="500" autocomplete="off">
        <button id="sendBtn">Send</button>
      </div>
    </div>
  </div>
</section>

<section class="explore" id="explore">
  <div class="explore-head">
    <div><h2>Explore skills</h2><div class="sub" id="exploreSub">Live board — updates as people post</div></div>
    <button class="btn btn-accent" id="postSkillBtn">+ Post a skill</button>
  </div>
  <div class="chips" id="chips"></div>
  <div class="masonry" id="masonry"></div>
</section>

<section class="how" id="how">
  <h2>How Skill Swap works</h2>
  <div class="how-grid">
    <div class="how-step"><div class="n">1</div><h3>List what you know</h3><p>Post a skill you can teach and what you'd like in return — no fixed pricing, just a fair trade.</p></div>
    <div class="how-step"><div class="n">2</div><h3>Get matched</h3><p>Save your profile and get matched live against everyone else on the board.</p></div>
    <div class="how-step"><div class="n">3</div><h3>Chat and swap</h3><p>Message your match right here, agree on a time, and meet to teach each other.</p></div>
    <div class="how-step"><div class="n">4</div><h3>Rate the swap</h3><p>Leave a review afterward — it builds trust and helps the next student pick a good match.</p></div>
  </div>
</section>

<footer>© Skill Swap · a student-built campus marketplace · no money, just skills</footer>

<div class="overlay" id="profOverlay">
  <div class="profmodal">
    <button class="authclose" id="closeProf">✕</button>
    <h2>Your swap profile</h2>
    <div class="sub">Saved to the shared board, visible to matches.</div>
    <form id="profForm">
      <div class="field"><label>Skills you can teach</label><input id="pTeach" placeholder="Guitar, Excel" value="<?= e($teachStr) ?>"></div>
      <div class="field"><label>Skills you want to learn</label><input id="pLearn" placeholder="Python, Photography" value="<?= e($learnStr) ?>"></div>
      <button type="submit">Save profile</button>
    </form>
  </div>
</div>

<div class="overlay" id="postOverlay">
  <div class="profmodal">
    <button class="authclose" id="closePost">✕</button>
    <h2>Post a skill</h2>
    <div class="sub">Goes live on the Explore board immediately for everyone.</div>
    <form id="postForm">
      <div class="field"><label>Skill title</label><input id="sTitle" required maxlength="120" placeholder="e.g. Basic yoga & stretching"></div>
      <div class="field"><label>Category</label><input id="sCategory" required maxlength="40" placeholder="e.g. Sports, Music, Coding"></div>
      <div class="field"><label>What you want in return</label><input id="sWants" required maxlength="160" placeholder="e.g. Help with statistics"></div>
      <div class="field"><label>Short description</label><textarea id="sDesc" maxlength="600" placeholder="What will sessions look like?"></textarea></div>
      <button type="submit">Post to the board</button>
    </form>
  </div>
</div>

<div class="toast" id="toast"></div>
<script src="app.js"></script>
<link rel="stylesheet" href="call.css?v=<?= filemtime(__DIR__ . "/call.css") ?>">
<script src="call.js?v=<?= filemtime(__DIR__ . "/call.js") ?>"></script>
<link rel="stylesheet" href="schedule.css?v=<?= filemtime(__DIR__ . "/schedule.css") ?>">
<script src="schedule.js?v=<?= filemtime(__DIR__ . "/schedule.js") ?>"></script>
<link rel="stylesheet" href="triangle.css?v=<?= filemtime(__DIR__ . "/triangle.css") ?>">
<script src="triangle.js?v=<?= filemtime(__DIR__ . "/triangle.js") ?>"></script>
</body>
</html>
