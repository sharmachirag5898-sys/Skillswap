/* Skill Swap — 3-way matches. Shown under "Find a match" only when you have no direct 1-to-1 swap.
   Talks to api_triangle.php; sends proposals through the existing chat API (api_chat.php). */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const toast = m => (typeof showToast === 'function' ? showToast(m) : alert(m));
  const anchor = $('matchesResult');
  if (!anchor) return;

  const box = document.createElement('div');
  box.id = 'triSection';
  box.style.display = 'none';
  anchor.after(box);

  const list = a => a.join(', ');
  const av = p => `<span class="avatar tri-av">${esc((p.name || '?').trim().charAt(0).toUpperCase())}<span class="pres ${p.online ? 'on' : ''}"></span></span>`;
  let lastSig = '', data = null;

  function render() {
    if (!data || data.hasDirect || !data.triangles.length) { box.style.display = 'none'; box.innerHTML = ''; lastSig = ''; return; }
    const sig = JSON.stringify(data.triangles);
    box.style.display = 'block';
    if (sig === lastSig) return;       // nothing changed: don't redraw (keeps buttons stable)
    lastSig = sig;
    box.innerHTML = `
      <h3 class="tri-h">🔁 No direct swap yet — try a 3-way swap</h3>
      <p class="tri-sub">Nobody who wants your skills teaches what you want, but three people can complete the circle: each of you teaches one person and learns from another.</p>
      ${data.triangles.map((t, i) => `
        <div class="tri-card">
          <div class="tri-flow">
            <div class="tri-node">${av({ name: 'You', online: true })}<b>You</b></div>
            <div class="tri-arrow"><small>${esc(list(t.meToP))}</small>→</div>
            <div class="tri-node">${av(t.p)}<b>${esc(t.p.name)}</b></div>
            <div class="tri-arrow"><small>${esc(list(t.pToQ))}</small>→</div>
            <div class="tri-node">${av(t.q)}<b>${esc(t.q.name)}</b></div>
            <div class="tri-arrow"><small>${esc(list(t.qToMe))}</small>→</div>
            <div class="tri-node tri-back"><b>back to you</b></div>
          </div>
          <ul class="tri-steps">
            <li>You teach <b>${esc(t.p.name)}</b>: ${esc(list(t.meToP))}</li>
            <li><b>${esc(t.p.name)}</b> teaches <b>${esc(t.q.name)}</b>: ${esc(list(t.pToQ))}</li>
            <li><b>${esc(t.q.name)}</b> teaches you: ${esc(list(t.qToMe))}</li>
          </ul>
          <div class="tri-actions">
            <button type="button" class="tri-btn tri-go" data-i="${i}">Propose this swap</button>
            <button type="button" class="tri-btn" data-chat="${t.p.id}" data-name="${esc(t.p.name)}">Message ${esc(t.p.name)}</button>
            <button type="button" class="tri-btn" data-chat="${t.q.id}" data-name="${esc(t.q.name)}">Message ${esc(t.q.name)}</button>
            ${window.SkillSwapSchedule ? `<button type="button" class="tri-btn" data-sched="${t.p.id}">📅 Schedule with ${esc(t.p.name)}</button><button type="button" class="tri-btn" data-sched="${t.q.id}">📅 Schedule with ${esc(t.q.name)}</button>` : ''}
          </div>
        </div>`).join('')}`;
    box.querySelectorAll('[data-chat]').forEach(b => b.addEventListener('click', () => {
      if (typeof openChat === 'function') openChat(+b.dataset.chat, b.dataset.name);
    }));
    box.querySelectorAll('[data-sched]').forEach(b => b.addEventListener('click', () => window.SkillSwapSchedule.open(+b.dataset.sched)));
    box.querySelectorAll('.tri-go').forEach(b => b.addEventListener('click', () => propose(data.triangles[+b.dataset.i], b)));
  }

  // Sends one friendly message to each of the two other people through the normal chat.
  async function propose(t, btn) {
    btn.disabled = true; btn.textContent = 'Sending…';
    const send = (to, body) => fetch('api_chat.php?action=send', {
      method: 'POST', credentials: 'same-origin', body: new URLSearchParams({ to, body })
    }).then(r => { if (!r.ok) throw new Error('send'); });
    const toP = `Hi ${t.p.name}! Skill Swap found a 3-way swap for us: I teach you ${list(t.meToP)}; you teach ${t.q.name} ${list(t.pToQ)}; and ${t.q.name} teaches me ${list(t.qToMe)}. I've sent ${t.q.name} the same idea. Interested?`;
    const toQ = `Hi ${t.q.name}! Skill Swap found a 3-way swap for us: I teach ${t.p.name} ${list(t.meToP)}; ${t.p.name} teaches you ${list(t.pToQ)}; and you teach me ${list(t.qToMe)}. I've sent ${t.p.name} the same idea. Interested?`;
    try {
      await Promise.all([send(t.p.id, toP), send(t.q.id, toQ)]);
      btn.textContent = 'Proposal sent ✓';
      toast('Proposal sent to ' + t.p.name + ' and ' + t.q.name + '.');
    } catch (e) {
      btn.disabled = false; btn.textContent = 'Propose this swap';
      toast('Could not send the proposal. Please try again.');
    }
  }

  async function load() {
    try {
      const r = await fetch('api_triangle.php', { credentials: 'same-origin' });
      if (!r.ok) return;
      data = await r.json();
      render();
    } catch (e) { /* ignore, try again next tick */ }
  }

  load();
  setInterval(load, 8000);
  const save = $('findMatchBtn');
  if (save) save.addEventListener('click', () => setTimeout(load, 700)); // refresh right after saving skills
})();
