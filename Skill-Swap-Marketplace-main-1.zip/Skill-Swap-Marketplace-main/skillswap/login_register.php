<?php
require_once 'config.php';

function fail(string $key, string $formName, string $message, array $old = []): void {
    $_SESSION[$key] = $message;
    $_SESSION['active_form'] = $formName;
    if ($old) {
        $_SESSION['old'] = $old;
    }
    header("Location: index.php");
    exit();
}

if (isset($_POST['register'])) {
    $name   = trim($_POST['name'] ?? '');
    $email  = strtolower(trim($_POST['email'] ?? ''));
    $plain  = $_POST['password'] ?? '';
    $bio    = mb_substr(trim($_POST['bio'] ?? ''), 0, 500);
    $offer  = $_POST['skills_offer'] ?? '';
    $want   = $_POST['skills_want'] ?? '';
    $old = ['name' => $name, 'email' => $email, 'bio' => $bio, 'skills_offer' => $offer, 'skills_want' => $want];

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fail('register_error', 'register', 'Please enter a valid name and email', $old);
    }
    if (strlen($plain) < 8) {
        fail('register_error', 'register', 'Password must be at least 8 characters', $old);
    }

    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        fail('register_error', 'register', 'Email is already registered', $old);
    }

    $hash = password_hash($plain, PASSWORD_DEFAULT);
    $conn->begin_transaction();
    try {
        $ins = $conn->prepare("INSERT INTO users (name, email, password, bio) VALUES (?, ?, ?, ?)");
        $ins->bind_param("ssss", $name, $email, $hash, $bio);
        $ins->execute();
        $userId = $conn->insert_id;

        saveSkills($conn, $userId, $offer, 'offer');
        saveSkills($conn, $userId, $want, 'want');
        $conn->commit();
    } catch (Throwable $ex) {
        $conn->rollback();
        fail('register_error', 'register', 'Could not create account, please try again', $old);
    }

    // Log the new user straight in
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['name']    = $name;
    $_SESSION['email']   = $email;
    $_SESSION['role']    = 'user';
    header("Location: user_page.php");
    exit();
}

if (isset($_POST['login'])) {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['name']    = $user['name'];
        $_SESSION['email']   = $user['email'];
        $_SESSION['role']    = $user['role'];

        header("Location: " . ($user['role'] === 'admin' ? 'admin_page.php' : 'user_page.php'));
        exit();
    }
    fail('login_error', 'login', 'Incorrect email or password');
}

header("Location: index.php");
exit();
