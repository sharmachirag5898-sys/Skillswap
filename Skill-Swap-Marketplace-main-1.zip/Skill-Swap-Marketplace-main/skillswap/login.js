function showForm(formId) {
    document.querySelectorAll(".form-box").forEach(f => f.classList.remove("active"));
    document.getElementById(formId).classList.add("active");
}

// Tag input: type a skill, press Enter or comma. Stored in a hidden comma-separated field.
document.querySelectorAll(".tag-input").forEach(box => {
    const name = box.dataset.name;
    const hidden = document.createElement("input");
    hidden.type = "hidden";
    hidden.name = name;
    const field = document.createElement("input");
    field.type = "text";
    field.placeholder = "Add a skill…";
    field.maxLength = 60;
    let tags = [];

    function sync() {
        hidden.value = tags.join(",");
        box.querySelectorAll(".tag").forEach(t => t.remove());
        tags.forEach((t, i) => {
            const chip = document.createElement("span");
            chip.className = "tag";
            chip.textContent = t + " ";
            const x = document.createElement("button");
            x.type = "button";
            x.textContent = "×";
            x.onclick = () => { tags.splice(i, 1); sync(); };
            chip.appendChild(x);
            box.insertBefore(chip, field);
        });
    }
    function add(value) {
        value = value.trim().toLowerCase();
        if (value && !tags.includes(value) && tags.length < 15) { tags.push(value); sync(); }
    }

    field.addEventListener("keydown", ev => {
        if (ev.key === "Enter" || ev.key === ",") {
            ev.preventDefault();
            add(field.value);
            field.value = "";
        } else if (ev.key === "Backspace" && !field.value && tags.length) {
            tags.pop(); sync();
        }
    });
    field.addEventListener("blur", () => { add(field.value); field.value = ""; });

    box.appendChild(field);
    box.appendChild(hidden);
    box.addEventListener("click", () => field.focus());
    (box.dataset.initial || "").split(",").forEach(add);
});
