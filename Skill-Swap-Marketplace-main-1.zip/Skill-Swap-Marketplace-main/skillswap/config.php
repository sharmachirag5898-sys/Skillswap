<?php
// Shared bootstrap: DB connection, session, helpers.
$host = "localhost";
$user = "root";
$password = "";
$database = "user_db";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Connect to the MySQL server first, then create the database/tables automatically if they don't exist yet.
    $conn = new mysqli($host, $user, $password);
    $conn->set_charset("utf8mb4");
    $conn->query("CREATE DATABASE IF NOT EXISTS `$database` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $conn->select_db($database);
    ensureSchema($conn);
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    die("<h2 style='font-family:sans-serif'>Skill Swap can't reach MySQL</h2><p style='font-family:sans-serif'>Start MySQL (XAMPP &rarr; Start MySQL) and check the username/password in config.php.<br><small>" . htmlspecialchars($e->getMessage()) . "</small></p>");
}

function ensureSchema(mysqli $conn): void {
    $conn->query("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL, role ENUM('user','admin') NOT NULL DEFAULT 'user',
        bio VARCHAR(500) NOT NULL DEFAULT '', last_seen DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");
    $conn->query("CREATE TABLE IF NOT EXISTS skills (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60) NOT NULL UNIQUE) ENGINE=InnoDB");
    $conn->query("CREATE TABLE IF NOT EXISTS user_skills (
        user_id INT NOT NULL, skill_id INT NOT NULL, type ENUM('offer','want') NOT NULL,
        level ENUM('beginner','intermediate','expert') NOT NULL DEFAULT 'intermediate',
        PRIMARY KEY (user_id, skill_id, type),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    $conn->query("CREATE TABLE IF NOT EXISTS messages (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, sender_id INT NOT NULL, receiver_id INT NOT NULL, body TEXT NOT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_pair (sender_id, receiver_id, id), INDEX idx_recv (receiver_id, is_read),
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    $conn->query("CREATE TABLE IF NOT EXISTS posts (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, title VARCHAR(120) NOT NULL, category VARCHAR(40) NOT NULL,
        wants VARCHAR(160) NOT NULL, description VARCHAR(600) NOT NULL DEFAULT '', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_created (created_at), FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function requireLogin() {
    if (empty($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
}

/**
 * Save a comma-separated list of skills for a user.
 * Skills are normalised (trimmed, lower-cased) and de-duplicated.
 */
function saveSkills(mysqli $conn, int $userId, string $csv, string $type): void {
    $names = array_unique(array_filter(array_map(function ($s) {
        return mb_substr(trim(mb_strtolower($s)), 0, 60);
    }, explode(',', $csv))));

    $findSkill = $conn->prepare("SELECT id FROM skills WHERE name = ?");
    $addSkill  = $conn->prepare("INSERT INTO skills (name) VALUES (?)");
    $link      = $conn->prepare("INSERT IGNORE INTO user_skills (user_id, skill_id, type) VALUES (?, ?, ?)");

    foreach (array_slice($names, 0, 15) as $name) {
        $findSkill->bind_param("s", $name);
        $findSkill->execute();
        $row = $findSkill->get_result()->fetch_assoc();
        if ($row) {
            $skillId = (int)$row['id'];
        } else {
            $addSkill->bind_param("s", $name);
            $addSkill->execute();
            $skillId = $conn->insert_id;
        }
        $link->bind_param("iis", $userId, $skillId, $type);
        $link->execute();
    }
}
