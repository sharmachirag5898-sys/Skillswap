<?php
// JSON API for the Skill Swap page: stats, ticker, posts, profile, matches.
require_once 'config.php';
header('Content-Type: application/json');

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'auth']);
    exit();
}
$me = (int)$_SESSION['user_id'];
$action = $_GET['action'] ?? '';
$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
session_write_close();


function out($data) { echo json_encode($data); exit(); }

function skillsOf(mysqli $conn, int $uid): array {
    $res = ['offer' => [], 'want' => []];
    $st = $conn->prepare("SELECT s.name, us.type FROM user_skills us JOIN skills s ON s.id = us.skill_id WHERE us.user_id = ?");
    $st->bind_param("i", $uid);
    $st->execute();
    foreach ($st->get_result() as $r) { $res[$r['type']][] = $r['name']; }
    return $res;
}


// Guess a card category from a skill name (skills have no category column).
function guessCategory(string $n): string {
    $map = [
        'Music'=>['guitar','piano','violin','drum','sing','music','flute','ukulele','dj'],
        'Coding'=>['python','java','c++','code','coding','html','css','sql','react','program','web','app','data','machine learning','ai'],
        'Art'=>['draw','sketch','paint','art','illustrat','calligraph','photo','video','edit','animation'],
        'Design'=>['design','figma','ui','ux','canva','photoshop','logo'],
        'Sports'=>['cricket','football','badminton','tennis','yoga','gym','swim','chess','sport','fitness','run','dance'],
        'Business'=>['excel','finance','account','market','business','sales','resume','linkedin','startup','spreadsheet'],
        'Language'=>['english','hindi','french','spanish','german','japanese','korean','language','speaking'],
        'Soft Skills'=>['public speaking','debate','leadership','communication','interview','time management','writing'],
    ];
    $n = mb_strtolower($n);
    foreach ($map as $cat => $words) foreach ($words as $w) if (mb_strpos($n, $w) !== false) return $cat;
    return 'General';
}

if ($action === 'stats') {
    $students = (int)$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
    $skills   = (int)$conn->query("SELECT COUNT(*) c FROM posts")->fetch_assoc()['c']
              + (int)$conn->query("SELECT COUNT(*) c FROM user_skills WHERE type = 'offer'")->fetch_assoc()['c'];
    $chats    = (int)$conn->query("SELECT COUNT(*) c FROM (SELECT 1 FROM messages GROUP BY LEAST(sender_id, receiver_id), GREATEST(sender_id, receiver_id)) t")->fetch_assoc()['c'];

    $feed = [];
    foreach ($conn->query("SELECT p.title, u.name, UNIX_TIMESTAMP(p.created_at) ts FROM posts p JOIN users u ON u.id = p.user_id ORDER BY p.id DESC LIMIT 8") as $r) {
        $feed[] = ['ts' => (int)$r['ts'], 'text' => $r['name'] . ' posted a new skill — ' . $r['title']];
    }
    foreach ($conn->query("SELECT name, UNIX_TIMESTAMP(created_at) ts FROM users ORDER BY id DESC LIMIT 8") as $r) {
        $feed[] = ['ts' => (int)$r['ts'], 'text' => $r['name'] . ' joined the board'];
    }
    usort($feed, fn($a, $b) => $b['ts'] <=> $a['ts']);
    out(['students' => $students, 'skills' => $skills, 'chats' => $chats, 'feed' => array_slice($feed, 0, 10)]);
}

if ($action === 'posts') {
    $rows = [];
    $res = $conn->query("SELECT p.id, p.user_id, p.title, p.category, p.wants, p.description, UNIX_TIMESTAMP(p.created_at) ts, u.name
                         FROM posts p JOIN users u ON u.id = p.user_id ORDER BY p.id DESC LIMIT 100");
    foreach ($res as $r) {
        $rows[] = ['id' => (int)$r['id'], 'userId' => (int)$r['user_id'], 'title' => $r['title'], 'category' => $r['category'],
                   'wants' => $r['wants'], 'desc' => $r['description'], 'ts' => (int)$r['ts'] * 1000, 'teacherName' => $r['name'], 'mine' => (int)$r['user_id'] === $me];
    }
    // Every skill a user says they can teach also shows up as a card on the board.
    $wantsBy = [];
    foreach ($conn->query("SELECT us.user_id, s.name FROM user_skills us JOIN skills s ON s.id = us.skill_id WHERE us.type = 'want'") as $r) {
        $wantsBy[(int)$r['user_id']][] = ucfirst($r['name']);
    }
    $res = $conn->query("SELECT us.user_id, s.name, u.name AS uname, UNIX_TIMESTAMP(u.created_at) ts
                         FROM user_skills us JOIN skills s ON s.id = us.skill_id JOIN users u ON u.id = us.user_id
                         WHERE us.type = 'offer' ORDER BY u.id DESC, s.name LIMIT 100");
    foreach ($res as $r) {
        $uid = (int)$r['user_id'];
        $rows[] = ['id' => 's' . $uid . '-' . $r['name'], 'userId' => $uid, 'title' => ucfirst($r['name']), 'category' => guessCategory($r['name']),
                   'wants' => isset($wantsBy[$uid]) ? implode(', ', array_slice($wantsBy[$uid], 0, 3)) : 'Open to any skill swap',
                   'desc' => '', 'ts' => 0, 'teacherName' => $r['uname'], 'mine' => $uid === $me, 'fromSkill' => true];
    }
    out(['posts' => $rows]);
}

if ($action === 'post' && $isPost) {
    $title = mb_substr(trim($_POST['title'] ?? ''), 0, 120);
    $cat   = mb_substr(trim($_POST['category'] ?? ''), 0, 40);
    $wants = mb_substr(trim($_POST['wants'] ?? ''), 0, 160);
    $desc  = mb_substr(trim($_POST['desc'] ?? ''), 0, 600);
    if ($title === '' || $cat === '' || $wants === '') { http_response_code(400); out(['error' => 'missing']); }
    $st = $conn->prepare("INSERT INTO posts (user_id, title, category, wants, description) VALUES (?, ?, ?, ?, ?)");
    $st->bind_param("issss", $me, $title, $cat, $wants, $desc);
    $st->execute();
    out(['ok' => true]);
}

if ($action === 'profile') {
    if ($isPost) {
        $conn->begin_transaction();
        $del = $conn->prepare("DELETE FROM user_skills WHERE user_id = ?");
        $del->bind_param("i", $me);
        $del->execute();
        saveSkills($conn, $me, $_POST['teach'] ?? '', 'offer');
        saveSkills($conn, $me, $_POST['learn'] ?? '', 'want');
        $conn->commit();
    }
    $s = skillsOf($conn, $me);
    out(['teach' => $s['offer'], 'learn' => $s['want']]);
}

if ($action === 'matches') {
    $mine = skillsOf($conn, $me);
    $others = [];
    foreach ($conn->query("SELECT id, name, (last_seen IS NOT NULL AND last_seen > NOW() - INTERVAL 30 SECOND) AS online FROM users WHERE id <> $me") as $u) {
        $others[(int)$u['id']] = ['id' => (int)$u['id'], 'name' => $u['name'], 'online' => (bool)$u['online'], 'teach' => [], 'learn' => []];
    }
    foreach ($conn->query("SELECT us.user_id, us.type, s.name FROM user_skills us JOIN skills s ON s.id = us.skill_id WHERE us.user_id <> $me") as $r) {
        $k = $r['type'] === 'offer' ? 'teach' : 'learn';
        if (isset($others[(int)$r['user_id']])) $others[(int)$r['user_id']][$k][] = $r['name'];
    }
    $hits = [];
    foreach ($others as $o) {
        $a = array_values(array_intersect($o['teach'], $mine['want']));   // they teach what I want
        $b = array_values(array_intersect($o['learn'], $mine['offer']));  // I teach what they want
        $score = count($a) + count($b);
        if ($score > 0) $hits[] = ['id' => $o['id'], 'name' => $o['name'], 'online' => $o['online'], 'score' => $score,
                                   'theyTeach' => $a, 'theyWant' => $b, 'teach' => $o['teach'], 'learn' => $o['learn']];
    }
    usort($hits, fn($x, $y) => $y['score'] <=> $x['score']);
    out(['matches' => $hits]);
}

http_response_code(400);
out(['error' => 'bad action']);
