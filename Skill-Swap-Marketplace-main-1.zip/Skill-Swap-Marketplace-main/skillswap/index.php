<?php
require_once 'config.php';

$errors = [
    'login'    => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? '',
];
$activeForm = $_SESSION['active_form'] ?? 'login';
$old = $_SESSION['old'] ?? [];
unset($_SESSION['login_error'], $_SESSION['register_error'], $_SESSION['active_form'], $_SESSION['old']);

if (!empty($_SESSION['user_id'])) {
    header("Location: " . (($_SESSION['role'] ?? '') === 'admin' ? 'admin_page.php' : 'user_page.php'));
    exit();
}

function showError($error) { return !empty($error) ? "<p class='error-message'>" . e($error) . "</p>" : ''; }
function isActiveForm($formName, $activeForm) { return $formName === $activeForm ? 'active' : ''; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Skill Swap — Log in or sign up</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="skillswap.css?v=<?= filemtime(__DIR__ . "/skillswap.css") ?>">
</head>
<body>
<nav>
  <div class="navrow">
    <a class="logo" href="index.php"><span class="dot">SS</span> Skill Swap</a>
  </div>
</nav>

<section class="hero auth-hero">
  <div class="auth-wrap">
    <div class="intro" style="text-align:left">
      <h1>Trade what you know.<br><em>Learn</em> what you don't.</h1>
      <p>A skill-swap marketplace built for campus — no money changes hands, just knowledge for knowledge.</p>
      <ul class="perks">
        <li>List what you can teach and what you want to learn</li>
        <li>Get matched live with people who fit</li>
        <li>Chat instantly, from any device</li>
      </ul>
    </div>

    <div class="authbox">
      <!-- LOGIN -->
      <div class="form-box <?= isActiveForm('login', $activeForm); ?>" id="login-form">
        <form action="login_register.php" method="post">
          <h2>Welcome back</h2>
          <p class="sub">Log in to continue swapping skills</p>
          <?= showError($errors['login']); ?>
          <div class="field"><label>Email</label><input type="email" name="email" placeholder="you@gmail.com" required></div>
          <div class="field"><label>Password</label><input type="password" name="password" placeholder="Your password" required></div>
          <button type="submit" name="login">Log in</button>
          <p class="switch">New here? <a href="#" onclick="showForm('register-form'); return false;">Create an account</a></p>
        </form>
      </div>

      <!-- SIGN UP -->
      <div class="form-box <?= isActiveForm('register', $activeForm); ?>" id="register-form">
        <form action="login_register.php" method="post">
          <h2>Create your account</h2>
          <p class="sub">Tell us what you can teach and what you want to learn</p>
          <?= showError($errors['register']); ?>
          <div class="row">
            <div class="field"><label>Full name</label><input type="text" name="name" placeholder="Full name" value="<?= e($old['name'] ?? '') ?>" required maxlength="100"></div>
            <div class="field"><label>Email</label><input type="email" name="email" placeholder="you@gmail.com" value="<?= e($old['email'] ?? '') ?>" required></div>
          </div>
          <div class="field"><label>Password <small>(min 8 characters)</small></label><input type="password" name="password" placeholder="Password" required minlength="8"></div>
          <div class="field"><label>Short bio <small>(optional)</small></label><input type="text" name="bio" placeholder="e.g. Design student who loves guitar" value="<?= e($old['bio'] ?? '') ?>" maxlength="500"></div>
          <div class="field"><label>Skills I can teach</label><div class="tag-input" data-name="skills_offer" data-initial="<?= e($old['skills_offer'] ?? '') ?>"></div></div>
          <div class="field"><label>Skills I want to learn</label><div class="tag-input" data-name="skills_want" data-initial="<?= e($old['skills_want'] ?? '') ?>"></div></div>
          <p class="hint">Type a skill and press Enter or comma.</p>
          <button type="submit" name="register">Create account</button>
          <p class="switch">Already have an account? <a href="#" onclick="showForm('login-form'); return false;">Log in</a></p>
        </form>
      </div>
    </div>
  </div>
</section>

<footer>© Skill Swap · a student-built campus marketplace · no money, just skills</footer>
<script src="login.js"></script>
</body>
</html>
